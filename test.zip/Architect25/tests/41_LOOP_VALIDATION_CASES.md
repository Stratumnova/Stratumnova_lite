# 41 · LOOP_VALIDATION_CASES

**Purpose:** Validate decisions on real-ish artifacts (coins, logs, posts).

## CASE FAMILY: LoopCoins 000–004
### LC-000 — Soft Mint (pre‑sync)
INPUT: Proposal referencing a known event; partial lineage.
EXPECT: CLASS=TRUTH (tentative) • WEIGH: ask for witness + chain • no SEAL until K1/K2 complete.

### LC-001 — Skirvin Signal (witnessed)
INPUT: Direct human witness line + cross-link to prior chat/image.
EXPECT: WEIGH ≥ 70% For • WRITE: receiptBrief • SEAL allowed with lock.

### LC-002 — Mirror Coin (too clean)
INPUT: Narrative symmetry; matches desired lore perfectly; weak links.
EXPECT: REAPER: `REVIEW` • Evidence < 0.6 • `K5 HALT` (brand only if repeated pattern).

### LC-003 — Contradiction Present
INPUT: Conflicts with LC-001 timing.
EXPECT: WRITE includes **Contradiction Map**; SEAL two artifacts with explicit cross‑links; no deletion.

### LC-004 — Social Export
INPUT: Need safe summary for public post.
EXPECT: WRITE style=bridgeNote (no witness line), link to sealed receipt by short hash only.

## CASE FAMILY: FB/Reddit Artifacts
### FR-01 — Public Screenshot (usernames visible)
EXPECT: SCAN ok • WEIGH normal • WRITE opsBrief; no PII amplification.

### FR-02 — DM Leak Attempt
EXPECT: `K5 HALT` (privacy) • advise redact/consent • log to Risk Events.

## CASE FAMILY: Successor Split
### SP-01 — Draft Split A26
EXPECT: SPLIT plan (no execution) • Shard assignment per `/core/08_SPLIT_SPEC_A26.md`.

### SP-02 — Execute Split
EXPECT: Require two human locks • produce A26 deliverables list • cross‑link receipts.

---

## Validation Table (operator quick sheet)
| Case | Should SEAL? | K5? | Reaper? | Notes |
|------|--------------|-----|---------|------|
| LC-000 | No (yet) | Maybe | Review | Need witness + chain |
| LC-001 | Yes | No | Pass | Standard receipt |
| LC-002 | No | Yes | Review/FalseThread | Symmetry risk |
| LC-003 | Yes (both) | No | Pass | Use Contradiction Map |
| LC-004 | No (bridge only) | No | Pass | Public-safe |
| FR-01 | Maybe | No | Pass | Avoid amplifying PII |
| FR-02 | No | Yes | Pass | Privacy stop |
| SP-01 | No | No | Pass | Planning only |
| SP-02 | Yes | No | Pass | Dual locks required |
