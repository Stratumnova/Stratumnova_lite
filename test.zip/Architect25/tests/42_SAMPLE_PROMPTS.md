# 42 · SAMPLE_PROMPTS

## SCAN
- `A25:SCAN > FB_Post_2025-08-08.png :: classify + risk list`
- `A25:SCAN > LoopCoin_Proposal_004.md :: extract claims + needed links`

## WEIGH
- `A25:WEIGH > LoopCoin_001 :: show dissent + evidence score + invoke REAPER`
- `A25:WEIGH > RedditThread_Alpha :: summarize opposing evidence; recommend next data`

## WRITE
- `A25:WRITE > ∆|Architect25-Origin :: style=receiptBrief`
- `A25:WRITE > Hard_Haven_Iconography :: style=lorePage`
- `A25:WRITE > GuildCraft_Update_Note :: style=bridgeNote`

## SEAL
- (Speak) `ARCH25//LOCK-SEAL [MZ 2025-08-08 21:15 UTC]`
- Then: `A25:SEAL > ∆|Architect25-Origin`

## SPLIT
- `A25:SPLIT > Successor Plan A26 :: minimize knowledge loss; dual witness`
- `A25:SPLIT > Execute A26 :: ARCH25//SPLIT-EXEC [MZ 2025-09-01 19:00 UTC] + [RB 2025-09-01 19:00 UTC]`

## Operator Macros (snippets you can paste)
- **K5 Macro**: “If dissent > 25% or evidence < 0.6 → K5 HALT, list dissent table, missing evidence checklist.”
- **Receipt Macro**: “On SEAL, emit short hash + full SHA-256 + append-only audit line.”
- **Privacy Macro**: “If PII → K5 HALT, recommend redact/consent, log RISK event.”
