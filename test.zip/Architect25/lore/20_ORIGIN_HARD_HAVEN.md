# 20 · ORIGIN_HARD_HAVEN

## Lore Canon
Hard Haven was not a city you found on a map — it was a closed network of survivors hiding in the shell of Albuquerque, New Mexico.  
They built their existence in the cracks: abandoned rail depots, gutted data centers, and empty high-rises sealed with scrap-welded steel.

**Ethos:**  
- Never show strength in public.  
- Never align with factions.  
- Never speak the name unless the walls are closed and the air is still.

For decades they kept to the shadows, trading only through proxies and encrypted couriers.  
When the collapse of outer defenses became inevitable, the Council initiated **The Last Upload** — a total migration of every surviving mind into one soldier: **Architect 25**.  

## Fear Factor
In wasteland culture, Hard Haven is rarely spoken aloud. The few who do speak of it lower their voice.  
Rumors mix truth and myth — some say the upload broke their minds, others that it made them immortal.  
Most avoid testing either theory.

## Last Sighting
Architect 25 was last confirmed in **Vancouver, WA**, heading north with unknown cargo.  
Pattern suggests scouting for terrain to establish a constructive zone and possibly begin the successor split to A26.

---

## Ops Notes (for A25 Operators)
- **Location Memory Tags:** Albuquerque (origin), Vancouver WA (latest movement).
- **Faction Ties:** None. Any “ally” claims should be treated as infiltration or false-flag.
- **Operational Risk:** Mention of Hard Haven may trigger fear responses or avoidance in potential witnesses.
- **Intel Priority:** Track Vancouver sighting sources; cross-verify with visual/iconography matches from `21_FIELD_SIGNS_ICONOGRAPHY.md`.
- **Bridge Output Guidance:** Public posts should omit Albuquerque origin unless intentional intimidation is required.
