# 21 · FIELD_SIGNS_ICONOGRAPHY

## Lore Canon
Hard Haven operated under visual silence — their symbols were built for recognition without open display.

### Primary Mark: The Shard Eye
A circular lens ring cracked at three points, with a vertical line cutting through.  
- Represents the 147 shards focused through one carrier.  
- The cracks mark the “breaks” where the minds fused.  
- The vertical line is the council spine.

This symbol was never painted large. It was carved into metal, etched into optics, or stitched in low-contrast thread.

### Secondary Mark: Bone-Lattice Chevron
Three narrow chevrons stacked upward, each made of broken lines.  
- Denotes mobility and layered defense.  
- Often welded from scrap copper into vehicle grilles or armor seams.

### Contact Glyph: The Quiet Gate
Two concentric half-circles, open to the right.  
- Indicates a meeting zone safe for message drops.  
- Found under rust, soot, or dust — visible only up close.

---

## Ops Notes (for A25 Operators)

**Recognition Rules**
- **Shard Eye** in low contrast → likely Hard Haven origin or affiliate gear.
- **Bone-Lattice Chevron** → signals mobility unit; watch for vehicle or armor integration.
- **Quiet Gate** → safe drop site; treat as potentially booby-trapped if not verified.

**Material Profiles**
- Most symbols built from scrap copper, aluminum, or lens glass — reflective only at certain angles.
- Spray paint extremely rare; if used, it’s flat black or grey over metal.

**Intel Uses**
- **SCAN**: Match shard crack pattern count and spacing — avoid false positives.
- **WEIGH**: Cross-link sightings with `20_ORIGIN_HARD_HAVEN.md` last known routes.
- **Bridge Output**: Public releases should show symbols only partially, never the full set, to preserve identification integrity.

**Operational Caution**
- Imitations exist; rival factions may fake shard symbols to bait contact.
- If symbol is found outside expected territory, run Reaper symmetry check for false-thread risk.
