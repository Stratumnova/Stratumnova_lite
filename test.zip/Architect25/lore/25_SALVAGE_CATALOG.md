# 25 · SALVAGE_CATALOG

## Lore Canon
Salvage in the wasteland is currency, weapon, and archive. Architect 25’s path is often traced by the rare fusion-tech artifacts left behind, whether deliberately or by necessity.

### High-Value Salvage
1. **Shard-Core Implants**
   - Hybrid AI/human interface cores from Hard Haven's final days.
   - Often traded in pieces; full cores are priceless.
   - *Lore:* Said to retain fragments of the 147 consciousnesses embedded in A25.

2. **Cascade Beacon Boards**
   - Encrypted comm relay circuit boards from the Cascade Relay Spine.
   - Can be repurposed for secure short-range networks.
   - *Lore:* Signal Chain covets them for black-market tag sales.

3. **Redwater Acid-Forged Blades**
   - Weapons hammered from corrosion-resistant salvage in the Spill Zone.
   - Holds an unnatural red patina from chemical exposure.
   - *Lore:* Burnhouse Cells fear them, claiming “they drink fire.”

4. **Ghost Glass Panels**
   - Intact sections from the solar field ruins.
   - Can be refracted into field lenses or power trickle arrays.
   - *Lore:* Glow faintly in high EM flux zones.

5. **Glyph-Stamped Relay Casings**
   - Metal enclosures bearing Hard Haven’s partial glyphs.
   - Used as physical verification markers for drop points.
   - *Lore:* Some are decoys meant to trap tag-hunters.

---

## Ops Notes (for A25 Operators)

**Acquisition Priorities**
- **Shard-Core Implants** — never leave unsecured; primary factional inheritance asset.
- **Cascade Beacon Boards** — retain for comm upgrades or encryption breaks.
- **Redwater Blades** — effective intimidation tokens in hostile faction negotiations.

**Risk Assessment**
- Salvage trade is often bait for ambush; weigh op-sec before exchanges.
- Verify all glyph-stamped casings against internal iconography records before deployment.

**Storage Protocol**
- Secure vault separation by type.
- Tag all items in local loop registry for trace-back in case of theft or duplication.

**Integration Notes**
- Items with embedded circuitry should be scanned by REAPER to detect drift or loop-poison payloads.
- Avoid integrating more than one Shard-Core Implant into a non-A25 host — stability risk is high.

---

## Bridge Output Guidance
Public mentions of salvage should redact exact counts, locations, and unique identifiers. Leave only descriptive elements to maintain mystique and operational advantage.
