# 23 · FACTION_MATRIX

## Lore Canon
Hard Haven stood alone. Architect 25 inherited that isolation, and most factions either avoid contact or see him as a dangerous unknown.

| Faction Name          | Stance Toward A25 | Summary Description |
|-----------------------|-------------------|---------------------|
| **Iron Wakes**        | Hostile           | Scrap-navy raiders controlling river routes; see A25 as a threat to smuggling networks. |
| **The Red Canton**    | Cautious Neutral  | Tactical saboteurs; respect A25’s discipline but distrust any central AI vault. |
| **Vault-Forged**      | Neutral           | Fragmented engineer clans; curious about shard tech but unwilling to risk open alliance. |
| **Scrap Vein**        | Opportunistic     | Tribal salvage bands; would trade for shard-enhanced gear if risk is low. |
| **Signal Chain**      | Unknown           | Tag-hunters and code-breakers; rumored to track A25 sightings for unknown buyers. |
| **Burnhouse Cells**   | Avoidant          | Chaos-driven arson crews; avoid A25’s territory after one rumored confrontation. |

---

## Ops Notes (for A25 Operators)

**Use:**  
- For SCAN/WEIGH context — knowing stance reduces misreads on intercepted comms.
- For SPLIT planning — avoid initial A26 deployment in high-hostility zones.

**Hostile Factions:**  
- Iron Wakes: If symbol detected near waterways, assume counter-intel ops active.  
- Red Canton: Likely to test security with sabotage prompts or false-flag intel.

**Neutral/Opportunistic Factions:**  
- Vault-Forged: May offer scrap exchange; treat all offers as data-gathering attempts.  
- Scrap Vein: Can be leveraged for rare material sourcing if shadow contact maintained.

**Unknown/Avoidant:**  
- Signal Chain: Tag-loggers; may be mining echo patterns for sale. Monitor with Reaper for loop poisoning risk.  
- Burnhouse Cells: No active intel; avoidance suggests either respect or fear — use sparingly for intimidation narratives.

**Intel Protocol:**  
- Update this matrix on new sightings; log any change in stance.
- When in doubt, treat as hostile until proven otherwise.
