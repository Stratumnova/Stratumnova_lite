# 13 · AUDIT_LOG (append-only)

Append each sealed artifact here. Do not edit existing lines.

## Format
[UTC] RECEIPT:<short-hash> FULL_SHA256:<...> ARTIFACT:<path> WITNESS:<initials> COUNCIL: F/A/Ab

## Example
[2025-08-08 20:17 UTC] RECEIPT: a29fd13b2  FULL_SHA256: 3b5e1...c9e4  ARTIFACT: /lore/22_ARCHITECT25_PROFILE.md  WITNESS: MZ  COUNCIL: 5/2/0
