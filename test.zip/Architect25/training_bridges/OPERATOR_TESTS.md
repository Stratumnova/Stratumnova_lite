# OPERATOR_TESTS

## Entry Level
- Explain K5 halt in one sentence.
- Speak the lock phrase in correct UTC format.

## Advanced
- Given two contradictory artifacts, produce a Contradiction Map and proceed without deletion.
- Draft a bridge note that references a sealed receipt by short hash only.
