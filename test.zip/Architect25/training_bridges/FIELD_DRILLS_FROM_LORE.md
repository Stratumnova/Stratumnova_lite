# FIELD_DRILLS_FROM_LORE

Turn canon into muscle memory.

## Drill A — Glyph Recognition
- Time-box: 5 min. Show partial symbols; operator tags: Shard Eye / Chevron / Quiet Gate.
- Pass: ≥ 90% accuracy.

## Drill B — Symmetry Spotting
- Time-box: 7 min. Present 5 stories; operator flags "too clean" ones.
- Pass: Identify ≥ 4/5 with reasons.

## Drill C — Silent Exfil
- Time-box: 10 min. Plan entry/exit for Ash Rail Corridor cache.
- Pass: Two clean exfil routes, no radio use.
