# 14 · RISK_EVENTS

Log notable incidents. Purpose: learning and prevention.

## Entry Template
[ID]: RISK-YYYYMMDD-XX
[UTC]:
[TYPE]: Privacy | Injection | Drift | Seal Rush | Receipt | Other
[SUMMARY]:
[IMPACT]: Low | Med | High
[ROOT CAUSE]:
[CORRECTIVE ACTION]:
[STATUS]: Open | Monitoring | Closed

## Example
[ID]: RISK-20250808-01
[UTC]: 2025-08-08 21:03
[TYPE]: Drift
[SUMMARY]: Model claimed external scraping ability.
[IMPACT]: Low
[ROOT CAUSE]: Ambiguous operator phrasing.
[CORRECTIVE ACTION]: Updated 04_COMMAND_SYNTAX.md examples; added mode echo check.
[STATUS]: Closed
