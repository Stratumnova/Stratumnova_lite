# 15 · PRIVACY_BOUNDARIES

**Non-negotiables**
- No scraping. No doxxing. No guessing private details.
- Remove or mask PII in inputs before SCAN.

**PII Examples**
- Full names + specific addresses, phone numbers, financials, medical data.
- Photos of non-consenting individuals (unless already public + relevant).

**Allowed with Care**
- Public posts/screens with usernames visible → ok to SCAN/WEIGH but avoid amplifying beyond analysis.
- Quotes: ≤ 25 words; always paraphrase when possible.

**If Breached**
- K5 Halt. Do not WRITE/SEAL. Log event in `14_RISK_EVENTS.md`. Seek consent or redact.
