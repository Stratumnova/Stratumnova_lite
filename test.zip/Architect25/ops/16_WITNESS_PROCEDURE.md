# 16 · WITNESS_PROCEDURE

## Purpose
Witnesses anchor artifacts to humans. Locks stop automation.

## Steps to Seal
1) Review WEIGH result (dissent ≤ 25%, evidence ≥ 0.6).
2) Read the artifact title aloud; confirm path.
3) Speak lock phrase exactly:
   ARCH25//LOCK-SEAL [<INITIALS YYYY-MM-DD HH:MM UTC>]
4) Operator runs `A25:SEAL > <artifact>` and captures the receipt.
5) Append to `13_AUDIT_LOG.md` immediately.

## Multi‑Witness (optional)
- For high‑value artifacts, collect two locks within the same minute block.
- Record both initials in the audit line.

## Revocation
- Not supported. Use REAPER to **brand** if later found compromised. Add corrective artifact referencing the branded receipt.

## Training Drill (5 min)
- Practice speaking the phrase with today’s UTC.
- Dry‑run a SEAL on a dummy artifact (no publication).
