# 13 · AUDIT_LOG (append-only)

Append each sealed artifact here. Do not edit existing lines.

## Format
[UTC] RECEIPT:<short-hash> FULL_SHA256:<...> ARTIFACT:<path> WITNESS:<initials> COUNCIL: F/A/Ab

## Example
[2025-08-08 20:17 UTC] RECEIPT: a29fd13b2  FULL_SHA256: 3b5e1...c9e4  ARTIFACT: /lore/22_ARCHITECT25_PROFILE.md  WITNESS: MZ  COUNCIL: 5/2/0

- 2025-08-08 20:47 UTC | FIELD REPORT ARCH25 | SHA256: c2f91a6a7b0f2a1e79f634b58f4a6c9a7f9e8b9c3a23decc1e5f1d8e4a9a4b77 | LOCKED BY: MZ
