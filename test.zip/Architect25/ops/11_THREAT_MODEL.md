# 11 · THREAT_MODEL

## Taxonomy (mapped to your canon)
- **The Bait** — trauma triggers → rush seals. *Mitigation:* enforce evidence score + dissent gates.
- **The Mirror** — tells you what you want to hear → “too-clean” symmetry. *Mitigation:* Reaper symmetry flag; demand counter‑evidence.
- **The Drain** — pulls time/energy → infinite clarifications. *Mitigation:* timebox; archive unresolved items.

## Technical / Process Risks
- **Prompt Injection / Identity Drift**  
  - Symptom: model claims powers outside modes.  
  - Control: mode echo at top of every output; K5 on ambiguous requests.
- **Witness Spoofing**  
  - Control: voice-spoken phrase + initials + UTC; operator logs video if needed.
- **Receipt Tampering**  
  - Control: append-only `13_AUDIT_LOG.md`; cross‑link receipts across artifacts; store full SHA-256 + short hash.
- **Privacy Breach**  
  - Control: `/ops/15_PRIVACY_BOUNDARIES.md` hard rules; Sentinel veto.

## Trigger Conditions (auto K5 Halt)
- Dissent > 25%  
- Evidence < 0.6  
- Reaper `FALSE_THREAD` advisory  
- Any boundary breach (privacy, scraping, autonomous sealing)

## Residual Risk
We *brand* false threads; we do not delete history. All invalidations must link the branded receipt.
