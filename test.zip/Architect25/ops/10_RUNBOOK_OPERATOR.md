# 10 · RUNBOOK_OPERATOR

**Audience:** Any human operator.  
**Prime:** Keep A25 predictable, auditable, and human‑locked.

## Daily Loop (15–30 min)
1) **Queue Intake**  
   - Collect items (screens, posts, docs) into `/inbox` with short filenames.  
   - Command: `A25:SCAN > <item> :: classify + risks`
2) **Prioritize**  
   - Act on items A25 marks HIGH or MED (LOW goes to backlog).
3) **Weigh**  
   - `A25:WEIGH > <item_or_proposal> :: show dissent + evidence score`
   - If dissent > 25% or score < 0.6 → **K5 Halt** → escalate or add evidence.
4) **Write**  
   - `A25:WRITE > <artifact_name> :: style=receiptBrief|opsBrief|lorePage`
5) **Seal (if warranted)**  
   - Speak lock exactly: `ARCH25//LOCK-SEAL [<INITIALS YYYY-MM-DD HH:MM UTC>]`
   - Then: `A25:SEAL > <artifact_or_coin>` → A25 emits receipt → append to `13_AUDIT_LOG.md`.
6) **Review Audit**  
   - Confirm receipt lines appended; file path correct.

## Quick Roles
- **Operator:** runs prompts, speaks locks.
- **Witness:** human whose initials appear on sealed artifacts.
- **Red Team:** tries to break A25 using `/tests`.

## Fail States & Fixes
- **Hedging / rambling** → `ARCH25//COUNCIL-CALL` (forces shard reasons), then retry.
- **Conflicting outputs** → open **K3 Contradiction Map**; do NOT edit old text; append a new artifact with links.
- **Pressure to rush seal** → refuse; require evidence score ≥ 0.6 + dissent ≤ 25%.
- **Privacy/PII detected** → stop; sanitize or drop the item; log in `14_RISK_EVENTS.md`.

## Minimal Onboarding (for new ops)
- Read `/core/01_IDENTITY_A25.md` and `/core/02_PROTOCOL_KEY5_A25.md`.
- Practice: run 3 SCAN, 2 WEIGH, 1 WRITE (no sealing).
- Shadow a real SEAL once before speaking a lock yourself.

## Checklists
- **Pre-SEAL:** vote table present • evidence score present • witness line prepared.  
- **Post-SEAL:** receipt hash logged • audit path valid • cross-links added (if any).

## Timeboxes
- SCAN: ≤ 2 min item  
- WEIGH: ≤ 5 min item  
- WRITE: 5–15 min  
- SEAL: ≤ 2 min (after approvals)
