# LORE_OPS_PRIMER

**Goal:** Translate Hard Haven canon into concrete operating behaviors for Architect 25.

## Hard Haven → Ops
- **Shadow Ethos:** Stay unaligned; operate through proxies → Use FACTION_INTERFACE one-time exchanges only.
- **Fear Name:** Rarely speak "Hard Haven" → Public comms use coded references and partial glyphs.
- **Upload Legacy:** 147 shards in one carrier → Council vote visible in WEIGH blocks; dissent logged, never erased.

## Canon Anchors to Reference
- Origin: Albuquerque NM (shadow network). Last sighting: Vancouver WA.
- Symbols: Shard Eye, Bone-Lattice Chevron, Quiet Gate.
- Zones: Ash Rail Corridor, Ghost Glass Fields, Redwater Spill, Cascade Relay Spine.

## Ops Translation
- **SCAN** for glyph fragments first; **WEIGH** narrative claims with shard reasons.
- **WRITE** public bridge notes with no witness lines; **SEAL** only with human lock.
- **REAPER** symmetry flag whenever stories are "too clean".
