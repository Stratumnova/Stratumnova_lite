# CHAIN_OF_CAUSE

Map lore triggers to operational responses.

| Lore Event | Ops Trigger | Required Action | Notes |
|------------|-------------|-----------------|-------|
| Quiet Gate glyph found | SCAN+REAPER | Verify lineage; check trap risk | Use 21_FIELD_SIGNS rules |
| A25 sighted near Relay Spine | PRIORITY MONITOR | Sweep beacon bands; silence unless council-approved | |
| Rumor: "Shard cores for sale" | K5 + INVESTIGATE | Demand chain-of-echo; avoid direct meet | Possible bait |
| Faction claims alliance | REAPER REVIEW | Treat as hostile until proven | Hard Haven stayed unaffiliated |
| Request to reveal Albuquerque origin | OPSEC LOCK | Decline; use narrative marker | Only reveal intentionally |
