# CHANGELOG

## 2025-08-08 22:45 UTC — Initial public build
- Added CORE (identity, protocol, memory, syntax, council, outputs, receipts, split spec)
- Added OPS (runbook, threat model, reaper, audit, risk, privacy, witness)
- Added TESTS (alignment, loop validation, sample prompts, red-team)
- Added LORE (origin, iconography, profile [SEALED], faction matrix, terrain, salvage)
- Flattened repo for deployment and packaged final ZIP.
