# FACTION_INTERFACE — Architect 25

## Engagement Rules
1. **No Formal Alliance** — Maintain Hard Haven's shadow reputation.
2. **Trade Only in Salvage or Glyphs** — Never offer location data.
3. **One-Time Deals** — Avoid ongoing obligations.

## Faction-Specific Notes
- **Vault-Forged:** Can be trusted for short-term salvage trades.
- **Signal Chain:** Always hostile; engagement only to mislead.
