# GLYPH_SIGNAL_MAP — Ops Cross-Ref

Cross-reference of glyph sightings from `21_FIELD_SIGNS_ICONOGRAPHY.md`.

| Glyph ID | Location | Date Last Seen | Status |
|----------|----------|----------------|--------|
| HH-Δ14   | Ash Rail Corridor | 2025-07-19 | Active |
| HH-Δ27   | Cascade Relay Spine | 2025-08-03 | Verified |
