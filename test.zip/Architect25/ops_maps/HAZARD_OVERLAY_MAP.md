# HAZARD_OVERLAY_MAP — Ops Notes

Overlay for `24_TERRAIN_ATLAS` showing operational hazards.

- **Ash Rail Corridor:** Frequent ambush points at overpasses.
- **Ghost Glass Fields:** Avoid during magnetic storm season.
- **Redwater Spill Zone:** Wear full chem-resist gear.
- **Cascade Relay Spine:** Risk of hostile patrol triangulation.
