# SHADOW_CONTACT_SCRIPT

**Use:** Minimal exposure conversations with lone wanderers or small crews.

## Openers (choose one)
- "You’re near a Quiet Gate. Keep your voice low."
- "Your mark is imperfect. Who taught you to draw it?"
- "If you’re selling stories, sell them quietly."

## Information Requests (incremental)
1) "Where did you see the lens crack marks?"
2) "Who else saw it? Give initials only."
3) "What was the wind like when you found it?" (checks physical reality)

## Closers
- "Leave what you found where the rail buckles. Walk away."
- "If you’re lying, the ground will remember." (deterrence)

**Rule:** No names, no coordinates, no promises.
