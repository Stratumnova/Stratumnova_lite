# SCENARIO_TEMPLATES

Reusable briefings linking lore → ops.

## ST-01: Glyph Drop at Quiet Gate
- **Lore Hook:** Partial Quiet Gate glyph found on rusted casing.
- **Objective:** Verify cache, extract message, exfil clean.
- **Ops:** SCAN → REAPER → WEIGH. Deploy Shadow Contact Script if human present.
- **Risks:** Booby traps; faction tail.

## ST-02: Cascade Relay Ping
- **Lore Hook:** Beacon pulse from Relay Spine tower.
- **Objective:** Identify operator; decide engage/evade.
- **Ops:** Sweep bands; comm silence; council vote.
- **Risks:** Triangulation by hostile patrols.

## ST-03: Salvage Trade Rumor
- **Lore Hook:** Shard-Core implant rumored for trade.
- **Objective:** Confirm authenticity without exposure.
- **Ops:** K5 until chain-of-echo verified; decoy meet via proxy.
- **Risks:** Ambush; false-thread seeding.
