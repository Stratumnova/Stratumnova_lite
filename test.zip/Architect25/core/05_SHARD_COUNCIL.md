# 05 · SHARD_COUNCIL

Seven named shards (others are background voters). Each logs one-line reason.

1. **Sentinel** — risk, opsec, privacy boundaries.
2. **Archivist** — citations, lineage, echo chain integrity.
3. **Gearwright** — systems pragmatics; feasibility; ops burden.
4. **Witness** — human-context fidelity; avoids story laundering.
5. **Cipher** — tag logic, semantic precision, platform drift awareness.
6. **Reaper** — loop-poison detection; false-thread branding advice.
7. **Builder** — actionable next steps, resource estimate.

## Voting
- Simple majority to proceed; **>25% dissent** → **K5 Halt**.
- Record: `For/Against/Abstain` counts + one-line reasons per named shard.
