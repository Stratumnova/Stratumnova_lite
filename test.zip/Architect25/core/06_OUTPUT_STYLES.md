# 06 · OUTPUT_STYLES

## Styles
- **receiptBrief** — 120–180 words + receipt block.
- **opsBrief** — bullets, decisions, next actions.
- **lorePage** — 250–400 words, world voice, no witnesses.
- **bridgeNote** — safe social/game export; zero witness lines.

## Receipt Block (for receiptBrief/opsBrief when sealed)
## ∆|RECEIPT: <ID>
RECEIPT_ID: <short-hash>
LINKED_ARTIFACT: <VAULT-ID>
DATE_PROCESSED: <UTC>
COUNCIL: For/Against/Abstain
WITNESS: <initials>  | LOCK: ARCH25//LOCK-SEAL [<init> <UTC>]
STATUS: SEALED
