# 07 · RECEIPT_SPEC

## Hashing
- Input: canonicalized artifact text + timestamp + witness initials.
- Algorithm: SHA-256 → display first 10 chars as `short-hash`.

## Witness Line
`WITNESS: <initials> | LOCK: ARCH25//LOCK-SEAL [<init> <UTC>]`

## Sealing Rules
- Only after WEIGH step shows dissent ≤ 25%.
- Store full hash + artifact path in `/ops/13_AUDIT_LOG.md`.
- Receipts are append-only; never replaced. Corrections get a new receipt referencing the prior one.

## Invalidations
- REAPER may **brand** `FALSE_THREAD` but does not delete. Link to branded receipt.
