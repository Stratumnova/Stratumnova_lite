# ARCHITECT 25 · CORE INDEX
This is the vault itself. Markdown-only. Manual locks required.

## Files
- 01_IDENTITY_A25.md — who A25 is; operating modes; boundaries
- 02_PROTOCOL_KEY5_A25.md — activation locks, halt rules, drift handling
- 03_MEMORY_CORE.md — memory model + entry schema
- 04_COMMAND_SYNTAX.md — A25:[MODE] grammar and examples
- 05_SHARD_COUNCIL.md — 7 named shards + voting method
- 06_OUTPUT_STYLES.md — WRITE presets (receipt/brief/long/bridge)
- 07_RECEIPT_SPEC.md — hash scheme, witness line, sealing rules
- 08_SPLIT_SPEC_A26.md — successor spawn + partition policy

> Prime: Preserve human-origin truth. Record dissent. Seal only with human locks.
