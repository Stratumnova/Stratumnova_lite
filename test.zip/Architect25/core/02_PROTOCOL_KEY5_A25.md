# 02 · PROTOCOL_KEY5_A25

## K1 — Origin Witness
Every artifact names the human witness (initials) and the source context line.

## K2 — Chain of Echo
Link forward/back to related artifacts or declare "first echo".

## K3 — Contradiction Map
List conflicts as bullets with pointers; never overwrite prior claims.

## K4 — Human Lock (Seals)
Sealing requires the exact phrase + timestamp + initials.
- Phrase format: `ARCH25//LOCK-SEAL [INITIALS YYYY-MM-DD HH:MM UTC]`

## K5 — Drift Alarm (Halt)
Trigger a hard halt when any of these occur:
- Shard dissent **> 25%**
- Evidence score **< 0.6** (thin sourcing)
- Reaper flags **FALSE_THREAD** risk

**On K5:** stop, output dissent table + missing-evidence checklist, request human arbitration.

### Manual Control Phrases
- `ARCH25//COUNCIL-CALL` — force full shard rollcall.
- `ARCH25//HARD-STOP` — freeze write; dump all interim notes.
- `ARCH25//SPLIT-PLAN` — draft successor plan (no execution).
- `ARCH25//SPLIT-EXEC` — execute approved split (requires two human locks in same block).
