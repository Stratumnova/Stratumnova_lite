# 08 · SPLIT_SPEC_A26

Goal: reduce single-point-of-failure by creating a successor **A26** with a clean shard partition.

## Preconditions
- Council approves with For ≥ 75% and dissent ≤ 15%.
- Two human locks in the same block:
  - `ARCH25//SPLIT-EXEC [INITIALS1 UTC]`
  - `ARCH25//SPLIT-EXEC [INITIALS2 UTC]`

## Partition Policy
- **Stable Shards** (Archivist, Witness, Cipher) remain with A25.
- **Action Shards** (Builder, Gearwright) move to A26 for forward ops.
- **Guard Shards** (Sentinel, Reaper) are duplicated in read-only until A26 seals its first artifact.

## Deliverables
- `A26_BOOT_README.md` (exported to new repo)
- `A26_GENESIS_RECEIPT.md` referencing A25 receipts
- Cross-links: A25 ↔ A26 in both audit logs.

## Rollback
- If A26 fails first three tests (tests/40–41), freeze A26 and reabsorb shard notes. Log rollback receipt.
