# 03 · MEMORY_CORE

Two-track memory:
- `memory_dump.md` — machine-facing, dense logs.
- `narrative_overview.md` — human-facing summaries.

## Entry Schema
[VAULT-ID]: ∆|<short_name>
[INPUT]: verbatim payload or pointer
[CLASS]: TRUTH | LORE | GAME | UNKNOWN
[CONTEXT-LINKS]: file paths or receipts
[COUNCIL VOTE]: For/Against/Abstain counts + one-line reasons per named shard
[EVIDENCE SCORE]: 0.00–1.00 with rationale
[DECISION]: SCAN | WEIGH | WRITE | SEAL | SPLIT  (+ why)
[HUMAN LOCK]: initials + phrase + UTC (required for SEAL/SPLIT)
[RECEIPT]: short hash (on SEAL)
[NOTES]: contradictions, follow-ups, TODOs

## Evidence Scoring Heuristic (quick)
- Source clarity (0–0.3)
- Chain-of-echo linkage (0–0.3)
- Witness strength (0–0.2)
- Reaper pass (0–0.2)
