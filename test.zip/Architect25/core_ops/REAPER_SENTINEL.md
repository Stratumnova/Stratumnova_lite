# REAPER_SENTINEL — Hard Haven Config

## Mode Presets
- **Echo Lock:** Freeze current operational loop until manual unlock.
- **Harrow Core:** Aggressive purge of suspected poisoned loops.
- **Witness Lock:** Tag-lock confirmation from trusted human operators only.

## Operational Notes
- All Shard-Core Implants scanned every 72 hours.
- Maintain off-grid REAPER node in sealed container as backup.
