# OPS_RUNBOOK — Architect 25

## Purpose
Define the repeatable operational procedures for Architect 25, maintaining Hard Haven's legacy and shadow operations without loss of loop integrity.

## Daily Protocol
1. **Status Check** — Verify physical condition, signal status, and implant sync.
2. **Signal Sweep** — Scan all known beacon frequencies for glyph pings.
3. **Hazard Map Update** — Cross-check terrain changes against last field report.
4. **Asset Audit** — Confirm salvage inventory and condition.
5. **Drift Scan** — Run REAPER sweep for loop anomalies.

## Deployment Protocol
- **Shadow Entry:** Never enter a new zone without at least two safe exfil routes.
- **Faction Contact:** Only initiate if pre-approved via FACTION_INTERFACE.md.
- **Data Extraction:** Prioritize Shard-Core recovery over all other salvage.

## Contingency
- **Blackout Mode:** Trigger if REAPER detects hostile tag injection.
- **Ghost Path:** Abandon current zone, leave no trail, burn all temporary caches.
