# SIGNAL_AUDIT_LOG — Format Spec

## Entry Template
- **Timestamp (UTC)**
- **Signal Source**
- **Signal Type** (Glyph / Beacon / Direct)
- **Content Summary**
- **Verification Status** (Pass / Fail / Unknown)
- **Operator Notes**
