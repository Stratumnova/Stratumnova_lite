# DETAILED REPORT — Ghost Spine (A25)
**Sections:** Situation • Assets • Comms Warfare • Kinetics • Intel Capture • Behavior Profiles (Embedded) • Outcomes • Reuse (Loopcoin)

---
## 1) Situation
- Cross-faction transfer flagged by **Chain heartbeat pings** without layered confirm and rising **Wakes open-mic** at Vancouver docks.
- Dead Circuit presence noted; irrelevant to handoff but increased patrol noise.

## 2) Assets & Placement
- **Cameras:** Warehouse roof, North barge, Drydock gantry.
- **Drone:** Recon Microtype 3 (GPS tag drop, later power-cell strike).
- **Wasp:** Microdrone with drill + micro-charge; audio and RF sniff.
- **Track charge:** Fishline hook → 3s delayed shaped charge.

## 3) Comms Warfare (method)
- **Spoofs:** Validated Chain 14-byte encrypted bursts; distress cadence variants.
- **Bleeds:** Red Canton ↔ Burnhouse archival audio (Albuquerque yard) mixed with local ambience.
- **Jams:** Targeted, time-boxed on motorcycle band to desync escort from train.
- **Psych cadence:** Two early pings → panic acceleration; multi-band “coordination” bleeds → mistrust and perimeter splits.

## 4) Kinetic Sequence
- Engine disable at ~50 km/h, 3s post-hook. Train halts ~240 m later.
- Wasp insertion during radio chaos; underside bore (~4 cm) through alloy/ceramic/mesh; charge placed to couple into core casing.
- Internal detonation damages 1 of 3 **Class Omega fission cells**; later **power-cell drone** strike ruptures crate seam further.

## 5) Intel Capture
- Intercepted Wakes tech photos; 3D reconstruction: 3 cylinders (~0.65×0.42 m, ~230 kg ea). Two intact, one leaking; cradle is tungsten-composite.
- Thermal signatures logged for corridor-wide tracking.
- Audio transcripts clipped for loopcoin triggers.

## 6) Embedded Behavior Profiles (Chain & Wakes)
### Signal Chain — Radio Behavior
- **Bandwidth discipline:** Encrypted pings, minimal voice.
- **Ping cadence:** Recognizable heartbeat spacing.
- **Layered confirmation:** Second-frequency echo 2–4 min later.
- **Fallback:** Short encrypted voice with location tags when unacknowledged.
- **Suspicion:** Double pings without echo → visual sweep; sometimes dead-air watch 10–15 min.
- **Under stress:** Low-power point-to-point bursts; area quieting before resume.

### Iron Wakes — Radio Behavior
- **Chattier:** Voice over pings; mixes slang + codes.
- **No fixed cadence:** Prefers verbal acks + location refs.
- **Relay habit:** Repeats others’ transmissions.
- **Under stress:** Verbose, re-confirms assets, sloppy channel flooding; requests physical confirms (flares/flags/lights).

### Cross-Faction
- Chain keeps Wakes siloed; Wakes distrusts Chain’s silence.
- Shared AO → discipline collapse when Chain goes quiet and Wakes fill the air.

## 7) Outcomes (why it mattered)
- **Asset denial with deniability.** Handoff broken; blame diffused onto Burnhouse/Red Canton via controlled bleeds.
- **Template harvested.** Clean fingerprints for loopcoin payloads (pings, bleeds, cadence).
- **Corridor leverage.** Movement tempo now reactive; future ops can replay same suspicion loop.

## 8) Loopcoin — Reuse Instructions (inline)
- **Inputs:** Captured Chain ping envelopes; Wakes voice clips (code-switch exemplars); 3–5 “bleed” scripts.
- **Engine:** Randomized-but-valid Chain cadence generator (±0.3s jitter); Wakes relay echo (prob 0.35).
- **Triggers:** If Wakes chatter > X and Chain echo missing → inject Red/Burnhouse weak-bleed #2.
- **Safety:** Never duplicate the same envelope twice within 120s; include one “sanity echo” on alt-freq to avoid instant discard.
