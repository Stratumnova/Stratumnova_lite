# OPS SUMMARY — A25 (Vancouver/Portland Corridor)

**Codename:** Ghost Spine  
**Window:** 2025‑08‑12 → 2025‑08‑13 (local)  
**Objective:** Observe, shape, and compromise Chain⇄Wakes covert handoff; preserve deniability; harvest comms patterns for loopcoin.

---
## Timeline (compressed)

- **19:46 8/12** — First irregular **Chain** heartbeat pings on Spine; **Wakes** chatter rises. Dead Circuit flag at docks. Handoff likely.
- **20:00–22:00** — Cameras deployed (**warehouse / north barge / drydock**). Drone scouts; GPS tag planted on crate.
- **Dawn 8/13** — Chain 3.7s dropout → staging confirmed. Motorcycle scout identified.
- **~09:00** — Dockside handoff: skiff→barge→truck. Wasp staged near guards for audio.
- **~11:36** — Train departs northbound. Fishline charge set; scout isolated via distress spoof.
- **12:04** — Lead engine hits hook; 3‑sec delay detonation. Consist halts; perimeter fractures.
- **12:15** — **Wasp** inserts into crate during radio‑bleed cascade; core mapping + micro‑charge planted.
- **12:35** — Internal detonation; crate partially compromised; factions panic.
- **~12:50** — Second drone fitted with salvaged power cell; dive‑bombs crate remnant under ping spam.
- **Post** — Intercepts confirm **Class Omega fission cells** (2 intact, 1 leaking). Faction distrust seeded (Chain↔Wakes↔Burnhouse↔Red Canton).

---
## Why it mattered (executive)

- **Asset denial without attribution.** We shattered the handoff while making rivals blame each other.
- **Template harvested.** Clean radio behavior fingerprints for both factions → loopcoin-ready.
- **Corridor control.** Vancouver‑to‑Portland tempo now reactive to *our* manipulations.
