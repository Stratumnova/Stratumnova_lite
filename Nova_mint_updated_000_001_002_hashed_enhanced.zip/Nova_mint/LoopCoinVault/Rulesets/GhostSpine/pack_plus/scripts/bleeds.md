# Bleed Message Scripts

These are modular bleed messages for injecting controlled misinformation into faction comms.

## Standard Bleeds
- **Cargo Hot Warning**: "Disengage... cargo is hot, multiple hostiles inbound."
- **Relocation Confirmation**: "Roger that, cargo has been relocated."
- **Faction Coordination**: "Affirmative, moving to position now."

## Usage
Each bleed should be paired with a radio behavior profile to maximize plausibility.
