# Loopcoin Rules Pack Extension

## Purpose
This pack adds advanced ops tooling for misinformation injection and comms loop exploitation.

## Contents
- `scripts/bleeds.md`: Modular bleed messages for rapid deployment.
- `statecharts/ghost_spine.mmd`: Decision-flow for comms interception and response.
- `fixtures/transcripts/sample_log.txt`: Example operational log for testing.

## Integration
Unzip into your Loopcoin rules folder. Ensure your runtime loads `scripts/` for message templates and `statecharts/` for decision automation.
