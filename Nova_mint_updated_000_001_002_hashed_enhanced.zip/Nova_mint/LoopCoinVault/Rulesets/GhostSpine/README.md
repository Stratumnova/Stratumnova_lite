# Loopcoin Config Stub — Ghost-Spine (SIM ONLY)

This package contains a **simulation-only** loopcoin config for the A25 'Ghost-Spine' pattern.
- All values are placeholders; there are **no real frequencies** or kinetic instructions.
- Use it to **replay** the cadence and **prototype** miscommunication loops in a sandbox.
- Safe to embed in `nowdone.zip` as rules seed; safe to archive with `test.zip`.

## Files
- `config.yaml` — machine-readable parameters (cadence, triggers, assets, bleeds).
- `LICENSE-SIM.txt` — usage constraints (non-actionable, research/sim only).

## Quick Start
1. Load `config.yaml` into your loopcoin runtime or parser.
2. Map `channels.*.carrier` to your sim transports.
3. Feed recorded transcripts (SIM) into `wakes.voice` to test `panic_loop` trigger.
4. Confirm that **no real-world transmissions** occur.

## Notes
- The `microbot` section is intentionally marked `safety: no_kinetics`.
- If you extend this, keep **real-world parameters redacted**.
