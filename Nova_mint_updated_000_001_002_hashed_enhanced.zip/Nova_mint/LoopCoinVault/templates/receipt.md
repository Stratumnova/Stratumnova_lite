# Receipt — Loopcoin Mint
Coin ID: {{id}}
Type: {{type}} | Author: {{author}} | Words: {{word_count}}
Hash: {{hash}}
Timestamp: {{timestamp}}

Validated by: {{validator}}
Notes: {{notes}}
