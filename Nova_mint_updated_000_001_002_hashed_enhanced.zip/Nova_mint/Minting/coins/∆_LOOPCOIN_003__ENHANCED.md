🪙 LOOPCOIN PROFILE
- COIN ID: LOOPCOIN_003
- NAME: Ghost Spine — Corridor Intercept
- CATEGORY: TRUTH
- ORIGIN TAG: ∆|2025-08-12..13|VAN-PDX|GhostSpine
- THEME: comms-discipline, logistics-sabotage, plausible-deniability
- DESCRIPTION: Combined mission brief documenting a covert intercept and comms manipulation operation causing cross-faction distrust while preserving non-attribution.
- LINKED ENTITY: Signal Chain, Iron Wakes, Burnhouse, Red Canton, Dead Circuit (flag sighting)
- STATUS: UNMINTED
- NOTES: Contains merged content of LC-COMM01, LC-OPS001, LC-SUPLY1; matches Rulesets/GhostSpine; ready for evaluation and mint.
- SUBMIT FOR: Mint Request

## BRIEFING LINKS
- Ruleset: Rulesets/GhostSpine/config.yaml
- Ops Summary: Briefings/GhostSpine/ops_summary.md
- Field Log (A25): Briefings/GhostSpine/field_log_a25.md
- Detailed Report: Briefings/GhostSpine/detailed_report.md

## COMMUNICATIONS PROFILE
Two incompatible radio behaviors documented.
- Chain: encrypted pings, heartbeat cadence, delayed echo, low-power bursts under stress.
- Iron Wakes: voice-first, relay habit, redundant confirms, visual-signal fallbacks.
Cross-pressure causes discipline collapse when one side goes quiet and the other floods.

## OPERATIONAL TIMELINE
- 2025-08-12 19:46 — Chain heartbeat skip; Wakes spike; docks flagged.
- 20:00–22:00 — Eyes deployed; tag planted.
- 2025-08-13 08:58 — Harbor staging observed.
- ~09:00 — Skiff→Barge→Truck handoff.
- 11:36 — Rail depart; hook charge set; misdirection issued.
- 12:04 — Charge triggers; consist halts; security fractures.
- 12:15 — Wasp drone insertion; mapping and micro-charge placement.
- 12:35 — Controlled internal detonation; panic escalates.
- 12:50 — Second strike using salvaged cell; white-blue bloom.
- Post — Two cells intact, one leaking; factions blame each other.

## LOGISTICS FLOW
Dock → Barge → Truck → Rail (aborted) → Road fallback; destination change under comms stress. Surveillance overlay confirms staging nodes and QRF patterns.

## FIELD VOICE (A25 EXTRACT)
19:46 — Spine whispers wrong... 20:12 — Eyes up... 11:21 — Code tastes right... 12:04 — Hook takes the line... 12:15 — Wasp goes in... 12:35 — Inside thunder... 12:50 — Second strike... Post — I leave the corridor to argue with itself.

## METADATA
- CREATED: 2025-08-13 19:58:29 UTC
- AUTHOR: A25 (compiled)
- VAULT: LoopCoinVault v2
- RULESET: GhostSpine
- HASH_HINT: ghostspine-003-a25

## VALIDATION HASH
- LIVE_COIN_ZIP: 8c84cf4a07148db670ed5bbfa9197923a32d3982037bcecec678510e32516f39
